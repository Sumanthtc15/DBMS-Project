<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "srms";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>